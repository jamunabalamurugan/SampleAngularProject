import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { RegisterService } from '../Shared/register.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {

  resetpasswordForm: FormGroup;
  submitted = false;
  resetID: any;
  newpassword: string;

  constructor(private formBuilder: FormBuilder, private register: RegisterService, private router: Router) { }

  ngOnInit() {
    this.resetpasswordForm = this.formBuilder.group({
      Password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', Validators.required]
    }, {
      validator: this.MustMatch('Password', 'confirmPassword')
    });
  }

  get f() { return this.resetpasswordForm.controls; }
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.resetpasswordForm.invalid) {
      return;
    }
  //  this.resetID = Number(parseInt(sessionStorage.getItem('ResetID')));

    { { debugger } }
    if (this.register.resetId) {
      // this.resetID = Number(sessionStorage.getItem('ResetID'));
      this.newpassword = this.resetpasswordForm.get('Password').value;
      { { debugger } }
      this.register.UpdatePassword(this.register.resetId, this.newpassword).subscribe(
        (data) => {
          alert(data);
        }
      )
    }
  }














  // -----------------------password matching-----------------
  MustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];

      if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        // return if another validator has already found an error on the matchingControl
        return;
      }

      // set error on matchingControl if validation fails
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ mustMatch: true });
      } else {
        matchingControl.setErrors(null);
      }
    }
  }
}
