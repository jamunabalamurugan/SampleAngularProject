import { Component, OnInit } from '@angular/core';
import { ExamService } from '../Shared/exam.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-exam',
  templateUrl: './exam.component.html',
  styleUrls: ['./exam.component.css']
})
export class ExamComponent implements OnInit {

  clicked: boolean = false;
  x: number;
  Tname: string;

  constructor(private quizService: ExamService, private router: Router) { }
  ngOnInit() {

    this.quizService.seconds = 0;
    this.quizService.qnProgress = 0;
    this.quizService.getQuestions(this.quizService.technology, this.quizService.level + 1).subscribe(
      (data: any) => {
        this.quizService.qns = data;
        this.startTimer();
      }
    );
  }

  startTimer() {
    this.quizService.timer = setInterval(() => {
      this.quizService.seconds++;
    }, 1000);
  }

  click(choice) {
    this.clicked = true;
    this.x = choice + 1;
    console.log(this.x);
  }

  Answer(qID) {

    this.quizService.qns[this.quizService.qnProgress].answer = this.x;
    this.clicked = false;
    this.x = -1;
    this.quizService.qnProgress++;
    if (this.quizService.qnProgress == 10) {
      clearInterval(this.quizService.timer);
      this.router.navigate(['/result']);
    }
  }

}
