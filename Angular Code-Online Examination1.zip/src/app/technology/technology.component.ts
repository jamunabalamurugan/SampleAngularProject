import { Component, OnInit } from '@angular/core';
import { ExamService } from '../Shared/exam.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-technology',
  templateUrl: './technology.component.html',
  styleUrls: ['./technology.component.css']
})
export class TechnologyComponent implements OnInit {

  id:string;
  
  constructor(private quizService:ExamService, private router:Router) { }

  ngOnInit() {
    
     this.id = JSON.stringify(sessionStorage.getItem('id'));
  }
  StartExam(techID){
    this.quizService.technology = techID;
  }

  Proceed(){
   this.router.navigateByUrl('/exam');
  }
}
