import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, EmailValidator } from '@angular/forms';
import { RegisterService } from '../Shared/register.service';
import { Router } from '@angular/router';
import { user } from '../class/user';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  signinForm: FormGroup;
  submitted = false;
  invalid= false;
  //Gdata:user;

  constructor(private formBuilder: FormBuilder, private signin: RegisterService, private router: Router) { }

  ngOnInit() {
    this.signinForm = this.formBuilder.group({
      Email: ['', [Validators.required, Validators.email]],
      Password: ['', [Validators.required, Validators.minLength(8)]],
      Type: ['', [Validators.required]]
    });
  }

  get f() { return this.signinForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.signinForm.invalid) {
      return;
    }

    // console.log(JSON.stringify(this.signinForm.value))
    this.signin.ValidateLogin(this.signinForm.value).subscribe(
      (data: number) => {
        if (data != -1) {
          // {{debugger}}
          if (data == this.signin.adminID[0] || data == this.signin.adminID[1]) {
            sessionStorage.setItem('id', data.toString());
            this.router.navigateByUrl('/adminhome')
          }
          else {
            sessionStorage.setItem('id', data.toString());
            this.router.navigateByUrl('/technology')
          }
        }
        else {
        this.invalid=true; 
        window.alert("Invalid credentials!!!...")
       //   alert("invalid");
        }
      }
    )
  }
}
