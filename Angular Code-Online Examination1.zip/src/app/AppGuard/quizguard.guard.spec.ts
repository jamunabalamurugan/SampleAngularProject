import { TestBed, async, inject } from '@angular/core/testing';

import { QuizguardGuard } from './quizguard.guard';

describe('QuizguardGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [QuizguardGuard]
    });
  });

  it('should ...', inject([QuizguardGuard], (guard: QuizguardGuard) => {
    expect(guard).toBeTruthy();
  }));
});
