import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http'
import { from } from 'rxjs';
import { report } from '../class/report';
//import { url } from 'inspector';

@Injectable({
  providedIn: 'root'
})
export class ExamService {


  readonly rootURL = "http://localhost:62881/";
//--------- EXAM VARIABLES-------------//
// questions: Questions[];
// current:number;

//---------NEW EXAM VARIABLES-------------//
qns: any[];
seconds: number;
timer;
qnProgress: number;
correctAnswerCount: number = 0;
technology:number;
techname=['','Java','SQL','PHP','C/C++','Python','C#/.net']
level =0;
result =[0,0,0]
 //-------LOGIN VARIABLES-------------//
//  email:string;
//  password:string;
 
  constructor(private http:HttpClient) { }

  displayTimeElapsed()
   {

    return Math.floor(this.seconds / 3600) + ':' + Math.floor(this.seconds / 60) + ':' + Math.floor(this.seconds % 60);

  }

  getQuestions(techID:number,level:number) {
    return this.http.get(this.rootURL+'quizgetquestions?tech='+techID+'&level='+level);
  }

  getAnswers(){
    var body = this.qns.map(x => x.QnID);
    return this.http.post(this.rootURL+'api/Answers',body);
  }

  getUserReports(uid)
  {
    return this.http.get(this.rootURL+'userreports?uid='+uid);
  }

  getUserProfile(uid)
  {
    return this.http.get(this.rootURL+'userprofile?uid='+uid);
  }

  putScore(data)
  {
    return this.http.put(this.rootURL+'submitscore',data)
  }




















  // GetQuestions()
  // {
  //    this.http.get(this.rootURL + 'api/exam/getquestions')
  //  .toPromise().then(res => this.questions = res as Questions[]); 
  //   // console.log(this.questions);
  // }
 
  // Login(email:string,password:string)
  // {
  //    //this.http.get(this.rootURL+'api/login/validateuser/'+email,password);
  // }
  
  
}
