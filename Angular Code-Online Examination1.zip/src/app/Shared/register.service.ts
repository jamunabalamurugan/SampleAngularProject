import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

// -------------LOGIN VARIABLES----------------
adminID=[10000,10001];
resetId: number;
//---------------------------------------------
 login:any={Email:"",Password:"",Type:"Admin"}

  readonly rootURL = "http://localhost:62881/";

  constructor(private http:HttpClient) { }

  RegisterUser(data)
  {
    return this.http.post(this.rootURL+'register',data);
  }

  ValidateLogin(data)
  {
    return this.http.post(this.rootURL+'validatelogin',data);
  }

  VerifyEmail(email)
  {
      return this.http.get(this.rootURL+'verifymail?email='+email);
  }

  UpdatePassword(id,newpass)
  {
    const headers = new HttpHeaders().set('content-type', 'application/json');
   {{debugger}}
      return this.http.put(this.rootURL+'resetpassword/'+id,newpass,{headers});
  }
}
