import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  readonly rootURL = "http://localhost:62881/";

  constructor(private http:HttpClient) { }

  QuestionAdd(data)
  {
    return this.http.post(this.rootURL+'addquestion',data);
  }

  GetQuestions()
  {
    return this.http.get(this.rootURL+'getquestions');
  }

  DeleteQuestion(QnID)
  {
    return this.http.delete('http://localhost:62881/deletequestion?QnID='+QnID);
  }

  GetReports()
  {
    return this.http.get(this.rootURL+'reports');
  }

  GetProfiles()
  {
    return this.http.get(this.rootURL+'profiles');
  }
}
