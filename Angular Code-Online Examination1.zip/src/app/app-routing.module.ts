import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { UserNavbarComponent } from './user-navbar/user-navbar.component';
import { HomeComponent } from './home/home.component';
import { ExamComponent } from './exam/exam.component';
import { ResultComponent } from './result/result.component';
import { TechnologyComponent } from './technology/technology.component';
import { SignupComponent } from './signup/signup.component';
import { SigninComponent } from './signin/signin.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { RemoveQuestionComponent } from './remove-question/remove-question.component';
import { EditquestionComponent } from './editquestion/editquestion.component';
import { ReportsComponent } from './reports/reports.component';
import { AuserprofilesComponent } from './auserprofiles/auserprofiles.component';
import { UserreportsComponent } from './userreports/userreports.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { SignoutComponent } from './signout/signout.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { QuizguardGuard } from './AppGuard/quizguard.guard';
import { FooterComponent } from './footer/footer.component';

const routes: Routes = [
  {path : 'signup', component: SignupComponent},
  {path : 'signin', component: SigninComponent},
  {path : 'signout', component: SignoutComponent},
  {path : 'footer', component: FooterComponent},
  {path : 'forgotpassword', component: ForgotpasswordComponent},
  {path : 'resetpassword', component: ResetpasswordComponent},
  {path : 'home', component:HomeComponent},
  {path: 'exam', component:ExamComponent, canActivate: [QuizguardGuard]},
  {path: 'result', component:ResultComponent, canActivate: [QuizguardGuard]},
  {path: 'adminhome', component:AdminhomeComponent, canActivate: [QuizguardGuard]},
  {path: 'reports', component:ReportsComponent, canActivate: [QuizguardGuard]},
  {path: 'userreports', component:UserreportsComponent, canActivate: [QuizguardGuard]},
  {path: 'auserprofiles', component:AuserprofilesComponent, canActivate: [QuizguardGuard]},
  {path: 'userprofile', component:UserprofileComponent, canActivate: [QuizguardGuard]},
  {path: 'technology', component:TechnologyComponent, canActivate: [QuizguardGuard]},
  {path: 'editquestion', component: EditquestionComponent, canActivate: [QuizguardGuard]},
  {path: 'remove-question', component:RemoveQuestionComponent, canActivate: [QuizguardGuard]},
  {path:'',redirectTo:'/home',pathMatch:'full'},
  {path:'**',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes),HttpClientModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }







