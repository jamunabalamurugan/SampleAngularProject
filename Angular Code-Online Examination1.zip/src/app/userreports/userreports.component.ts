import { Component, OnInit } from '@angular/core';
import { ExamService } from '../Shared/exam.service';

@Component({
  selector: 'app-userreports',
  templateUrl: './userreports.component.html',
  styleUrls: ['./userreports.component.css']
})
export class UserreportsComponent implements OnInit {

  reports:any[];

  constructor(private service:ExamService) { }
  userID ;
  ngOnInit() {
    this.userID = sessionStorage.getItem('id'); 
    this.service.getUserReports(this.userID).subscribe(
      (data:any)=>{
        this.reports=data;
      }
    )
  }

}
