import { Component, OnInit } from '@angular/core';
import { AdminService } from '../Shared/admin.service';
import { FormBuilder, FormGroup,NgForm, FormControlName, FormControl } from '@angular/forms';
import { AddQuestion } from '../class/AddQuestions';

@Component({
  selector: 'app-editquestion',
  templateUrl: './editquestion.component.html',
  styleUrls: ['./editquestion.component.css']
})
export class EditquestionComponent implements OnInit {

  questions: any[];


// -------------edit question variable----------------------

EditQuestion:AddQuestion;
// -------------------order by variables------------------

order =[true,true,true,true,true,true,true,true];

// ----------------------------------------------------------
  constructor(private service: AdminService) { }

  ngOnInit() {
    this.service.GetQuestions().subscribe(
      (res:any)=>{
        this.questions = res;
      }
    )

    
  }

  orderby(i){
    if(this.order[i])
        this.order[i]=false;
        else
        this.order[i]=true;
  }

 SelQuestion(i){
  this.EditQuestion = this.questions[i];
  console.log(this.EditQuestion)
  //  this.EditQuestion = i.
 }
}


