import { Component, OnInit } from '@angular/core';
import { ExamService } from '../Shared/exam.service';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {
 profile:any[];
 userID;
  constructor(private service:ExamService) { }

  ngOnInit() {
    this.userID = sessionStorage.getItem('id');  

    this.service.getUserProfile(this.userID).subscribe(
      (data:any)=>{
        this.profile =data;
        console.log('arrived');
      }
    )
  }

}
