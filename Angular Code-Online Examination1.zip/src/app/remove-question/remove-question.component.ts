import { Component, OnInit } from '@angular/core';
import { AdminService } from '../Shared/admin.service';

@Component({
  selector: 'app-remove-question',
  templateUrl: './remove-question.component.html',
  styleUrls: ['./remove-question.component.css']
})
export class RemoveQuestionComponent implements OnInit {



  questions: any[];

  delquestion:any[];

  constructor(private service: AdminService) { }

  ngOnInit() {
    this.service.GetQuestions().subscribe(
      (res:any)=>{
        this.questions = res;
      }
    )
  }

  del(QnNumber)
  {

    for (var qn of this.questions)
    {
      if(qn.QuestionNumber == QnNumber)
      {
        this.delquestion= qn;
      }
    }
  }

  DeleteConfirmed(QnId)
  {
    console.log(QnId)
    this.service.DeleteQuestion(QnId).subscribe(
      (res:any)=>{
        alert(res);
      }
    )
  }
}
