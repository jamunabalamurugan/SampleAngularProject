import { Component, OnInit } from '@angular/core';
import { AdminService } from '../Shared/admin.service';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {

  reports:any[];

  constructor(private service:AdminService) { }

  ngOnInit() {
    this.service.GetReports().subscribe(
      (data:any)=>{
        this.reports=data;
      }
    )
  }

}
