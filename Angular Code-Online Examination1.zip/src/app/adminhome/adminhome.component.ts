import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AddQuestion } from '../class/AddQuestions';
import { AdminService } from '../Shared/admin.service';


@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['./adminhome.component.css']
})
export class AdminhomeComponent implements OnInit {

// --------------modal forms variable--------------------------
AddQuestionForm:FormGroup;
submitted = false;
question:AddQuestion;


  constructor(private formBuilder: FormBuilder,private service:AdminService) { }

  ngOnInit() {
    this.AddQuestionForm = this.formBuilder.group(
      {
        Question1: ['',Validators.required],
        option1: ['', Validators.required],
        option2: ['', Validators.required],
        option3: ['', Validators.required],
        option4: ['', Validators.required],
        level: ['', Validators.required],
        TechnologyID:['', Validators.required],
        correct_answer:['', Validators.required],
      }
    )
  }
  get f() { return this.AddQuestionForm.controls; }

  // ----------------add question method------------------------
  AddQuestion()
  {
  //  {{debugger}}
    this.submitted = true;
    // stop here if form is invalid
    if (this.AddQuestionForm.invalid) {
      return;
    }
    this.question = this.AddQuestionForm.value;
  //  console.log(this.question);
    this.service.QuestionAdd(this.question).subscribe(
      (res:string)=>{
        alert(res);
        
      }
    )
  }

}
