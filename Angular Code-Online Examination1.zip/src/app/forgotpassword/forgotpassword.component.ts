import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from '../Shared/register.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {

  forgotpasswordForm: FormGroup;
  submitted = false;
  invalid = false;
  email: string;
  constructor(private formBuilder: FormBuilder, private signin: RegisterService, private router: Router) { }

  ngOnInit() {
    this.forgotpasswordForm = this.formBuilder.group({
      Email: ['', [Validators.required, Validators.email]],
    });
  }


  get f() { return this.forgotpasswordForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.forgotpasswordForm.invalid) {
      return;
    }
    //  const email = this.forgotpasswordForm.controls['Email']
    this.email = this.forgotpasswordForm.get('Email').value;
    console.log(this.email);
    { { debugger } }
    this.signin.VerifyEmail(this.email).subscribe(
      (data) => {
        if (data == -1) {
          alert('This Email is not yet registered!!!...')
        }
        else {
          this.signin.resetId = Number(data);
        //  sessionStorage.setItem('ResetId', data.toString());
          this.router.navigateByUrl('/resetpassword');
        }
      }
    )

  }
}
