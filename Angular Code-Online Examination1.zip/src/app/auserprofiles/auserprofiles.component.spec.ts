import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuserprofilesComponent } from './auserprofiles.component';

describe('AuserprofilesComponent', () => {
  let component: AuserprofilesComponent;
  let fixture: ComponentFixture<AuserprofilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuserprofilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuserprofilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
