import { Component, OnInit } from '@angular/core';
import { AdminService } from '../Shared/admin.service';

@Component({
  selector: 'app-auserprofiles',
  templateUrl: './auserprofiles.component.html',
  styleUrls: ['./auserprofiles.component.css']
})
export class AuserprofilesComponent implements OnInit {

  profiles:any[];
  constructor(private service:AdminService) { }

  ngOnInit() {
    this.service.GetProfiles().subscribe(
      (data:any)=>{
        this.profiles = data;
      }
    )
  }

}
