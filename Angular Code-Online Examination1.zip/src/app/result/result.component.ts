import { Component, OnInit } from '@angular/core';
import { ExamService } from '../Shared/exam.service';
import { Router } from '@angular/router';
import { report } from '../class/report';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {

  cleared=true;
  score:any={UserID:0,
    marksL1:0,
    marksL2:0,
    marksL3:0,
    TechnologyID:0};



  constructor(private quizService: ExamService, private router: Router) { }

  ngOnInit() {
    this.quizService.getAnswers().subscribe(
      (data: any) => {
        this.quizService.correctAnswerCount = 0;
        this.quizService.qns.forEach((e, i) => {
          if (e.answer == data[i])
            this.quizService.correctAnswerCount++;
          e.correct = data[i];
        });
      }
    );

  }

  NextLevel(level: number) {
    this.quizService.result[this.quizService.level] = this.quizService.correctAnswerCount;

    if (this.quizService.result[this.quizService.level] >= 5 && level < 2) {
      this.quizService.level++;
      this.router.navigate(['/exam'])
    }
    else if (this.quizService.result[this.quizService.level] < 5) {
      this.quizService.level=0;
      this.cleared=false;
      this.SubmitScore();
      alert('not cleared the level')
      this.router.navigate(['/technology'])
    }
    else {
      this.quizService.level=0; 
      this.cleared =false;
      this.SubmitScore();
      alert("level 3 completed");
      this.router.navigate(['/technology'])
    }
  }

  SubmitScore(){
    {{debugger}}
    this.score.TechnologyID = this.quizService.technology;
    this.score.UserID  = Number(sessionStorage.getItem('id'));
    this.score.marksL1 = this.quizService.result[0];
    this.score.marksL2 = this.quizService.result[1];
    this.score.marksL3 = this.quizService.result[2];

    this.quizService.putScore(this.score).subscribe(
      (msg:string) =>{
        console.log(msg);
      }
    );
    
    //console.log(this.score);
  }
}

