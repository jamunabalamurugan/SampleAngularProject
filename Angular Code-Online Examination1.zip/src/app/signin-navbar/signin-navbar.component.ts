import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signin-navbar',
  templateUrl: './signin-navbar.component.html',
  styleUrls: ['./signin-navbar.component.css']
})
export class SigninNavbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
