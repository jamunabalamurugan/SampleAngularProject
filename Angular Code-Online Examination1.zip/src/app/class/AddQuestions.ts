export class AddQuestion{
    Question1:string;
    option1:string;
    option2:string;
    option3:string;
    option4:string;
    level:number;
    TechnologyID:number;
    correct_answer:number;
}

