export class user{
    UserName:string;
    Email:string;
    Password:string;
    City:string;
    DOB:string;
    State:string;
    Mobile:string;
    Qualification:string;
    Year_of_completion:number;
}