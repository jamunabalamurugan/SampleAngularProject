export class report {
    UserID: number;
    marksL1: number;
    marksL2: number;
    marksL3: number;
    TechnologyID: number;
}