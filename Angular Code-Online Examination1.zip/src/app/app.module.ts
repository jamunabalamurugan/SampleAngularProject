import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminNavbarComponent } from './admin-navbar/admin-navbar.component';
import { UserNavbarComponent } from './user-navbar/user-navbar.component';
import { ExamService } from './Shared/exam.service';
import { HomeComponent } from './home/home.component';
import { ExamComponent } from './exam/exam.component';
import { ResultComponent } from './result/result.component';
import { TechnologyComponent } from './technology/technology.component';
import { SignupComponent } from './signup/signup.component';
import {FormsModule} from '@angular/forms'

import { from } from 'rxjs';
import { RegisterService } from './Shared/register.service';
import { SigninComponent } from './signin/signin.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AdminService } from './Shared/admin.service';
import { RemoveQuestionComponent } from './remove-question/remove-question.component';
import { EditquestionComponent } from './editquestion/editquestion.component';
import { ReportsComponent } from './reports/reports.component';
import { AuserprofilesComponent } from './auserprofiles/auserprofiles.component';
import { UserreportsComponent } from './userreports/userreports.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { SigninNavbarComponent } from './signin-navbar/signin-navbar.component';
import { QuizguardGuard } from './AppGuard/quizguard.guard';
import { SignoutComponent } from './signout/signout.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { FooterComponent } from './footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminNavbarComponent,
    UserNavbarComponent,
    HomeComponent,
    ExamComponent,
    ResultComponent,
    TechnologyComponent,
    SignupComponent,
    SigninComponent,
    AdminhomeComponent,
    RemoveQuestionComponent,
    EditquestionComponent,
    ReportsComponent,
    AuserprofilesComponent,
    UserreportsComponent,
    UserprofileComponent,
    SigninNavbarComponent,
    SignoutComponent,
    ForgotpasswordComponent,
    ResetpasswordComponent,
    FooterComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    Ng2SearchPipeModule
  ],
  providers: [ExamService, RegisterService,AdminService, QuizguardGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
