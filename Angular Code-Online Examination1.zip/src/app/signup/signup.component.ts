import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { user } from '../class/user';
import { RegisterService } from '../Shared/register.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit { 

  registerForm: FormGroup;
  submitted = false;
  userdata: user;
  constructor(private formBuilder: FormBuilder, private register:RegisterService,private router:Router) { }

  ngOnInit() {
        this.registerForm = this.formBuilder.group({
          UserName: ['', Validators.required],
            DOB: ['', Validators.required],
            City: ['', Validators.required],
            State: ['', Validators.required],
            Qualification: ['', Validators.required],
            Year_of_completion:['', Validators.required],
            Mobile: ['', [Validators.required, Validators.minLength(10)]],
           Email: ['', [Validators.required, Validators.email]],
           Password: ['', [Validators.required, Validators.minLength(8)]],
            confirmPassword: ['', Validators.required]
        }, {
            validator: this.MustMatch('Password', 'confirmPassword')
        });
    }


  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }
    this.userdata =(this.registerForm.value);
    this.register.RegisterUser(this.userdata).subscribe(
      (msg:string) =>{
        if(msg !=null)
        {
          alert(msg);
          this.router.navigateByUrl('/signin');
        }
      }
    )  
  }

  // ----------------------match fun-----------------------------------------
  MustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        const matchingControl = formGroup.controls[matchingControlName];

        if (matchingControl.errors && !matchingControl.errors.mustMatch) {
            // return if another validator has already found an error on the matchingControl
            return;
        }

        // set error on matchingControl if validation fails
        if (control.value !== matchingControl.value) {
            matchingControl.setErrors({ mustMatch: true });
        } else {
            matchingControl.setErrors(null);
        }
    }
}
}
  
