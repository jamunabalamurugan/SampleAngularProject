﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OnlineExaminationApi.Models;

namespace OnlineExaminationApi.Controllers
{
    public class AdminController : ApiController
    {
        [HttpPost]
        [Route("addquestion")]
        public HttpResponseMessage AddQuestion(Question q)
        {
            using (OnlineExaminationEntities db = new OnlineExaminationEntities())
            {
                db.Questions.Add(q);
                db.SaveChanges();
                return this.Request.CreateResponse(HttpStatusCode.OK, "Question Added Successfully");
            }
        }

        [HttpGet]
        [Route("getquestions")]

        public HttpResponseMessage GetQuestions()
        {
            using (OnlineExaminationEntities db = new OnlineExaminationEntities())
            {
                var Questions = db.Questions
                   .Select(x => new
                   {
                       x.QuestionNumber,
                       x.Question1,
                       x.option1,
                       x.option2,
                       x
                   .option3,
                       x.option4,
                       x.correct_answer,
                       x.TechnologyID,
                       x.Technology.TechnologyName,
                       x.level
                   })
                   .ToArray();

                return this.Request.CreateResponse(HttpStatusCode.OK, Questions);
            }
        }

        [HttpDelete]
        [Route("deletequestion")]
        public HttpResponseMessage DeleteQuestion(int QnID)
        {
            using (OnlineExaminationEntities db = new OnlineExaminationEntities())
            {
                Question id = db.Questions.Find(QnID);
                db.Questions.Remove(id);
                db.SaveChanges();
                return this.Request.CreateResponse(HttpStatusCode.OK, "Question Deleted Successfully");
            }
        }

        [HttpGet]
        [Route("reports")]
        public HttpResponseMessage GetReports()
        {
            using (OnlineExaminationEntities db = new OnlineExaminationEntities())
            {
                var report = db.Reports
                     .Select(x => new
                     {
                         UserID = x.UserID,
                         UserName = x.LoginDetail.UserName,
                         ExamID = x.ExamID,
                         Mark1 = x.marksL1,
                         Mark2 = x.marksL2,
                         Mark3 = x.marksL3,
                         TechName = x.Technology.TechnologyName
                     })
                     .ToArray();

                return this.Request.CreateResponse(HttpStatusCode.OK, report);
            }
        }

        [HttpGet]
        [Route("profiles")]
        public HttpResponseMessage GetProfiles()
         {
            using (OnlineExaminationEntities db = new OnlineExaminationEntities())
            {
                var profile = db.LoginDetails
                    .Where(y => (y.Type == "user"))
                    .Select(x => new
                    {
                        UserID = x.UserID,
                        UserName = x.UserName,
                        Email = x.Email,
                        DOB = x.DOB,
                        Qualification = x.Qualification,
                        Phone = x.Mobile,
                        City = x.City,
                        YOC = x.Year_of_completion,
                        State = x.State
                    })
                    .ToArray();

                return this.Request.CreateResponse(HttpStatusCode.OK, profile);
            }
        }
    }
}
