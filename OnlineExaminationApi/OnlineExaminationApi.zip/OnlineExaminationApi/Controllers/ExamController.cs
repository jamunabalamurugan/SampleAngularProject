﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OnlineExaminationApi.Models;

namespace OnlineExaminationApi.Controllers
{
    public class ExamController : ApiController
    {
        OnlineExaminationEntities db = new OnlineExaminationEntities();

        [HttpGet]
        [Route("quizgetquestions")]
        public HttpResponseMessage GetQuestions(int tech,int level)
        {

            using (OnlineExaminationEntities db = new OnlineExaminationEntities())

            {

                var Qns = db.Questions
                    .Where(z => z.TechnologyID == tech && z.level == level)
                    .Select(x => new { QnID = x.QuestionNumber, Qn = x.Question1, x.option1, x.option2, x.option3, x.option4 })
                    .OrderBy(y => Guid.NewGuid())
                    .Take(10)
                    .ToArray();
                var updated = Qns.AsEnumerable()
                    .Select(x => new
                    {
                        QnID = x.QnID,
                        Qn = x.Qn,
                        Options = new string[] { x.option1, x.option2, x.option3, x.option4 }
                    }).ToList();

                return this.Request.CreateResponse(HttpStatusCode.OK, updated);

            }

        }

        [HttpPost]
        [Route("api/Answers")]

        public HttpResponseMessage GetAnswers(int[] qIDs)
        {

            using (OnlineExaminationEntities db = new OnlineExaminationEntities())

            {
                var result = db.Questions
                     .AsEnumerable()
                     .Where(y => qIDs.Contains(y.QuestionNumber))
                     .OrderBy(x => { return Array.IndexOf(qIDs, x.QuestionNumber); })
                     .Select(z => z.correct_answer)
                     .ToArray();

                return this.Request.CreateResponse(HttpStatusCode.OK, result);
            }

        }

        [HttpGet]
        [Route("userreports")]
        public HttpResponseMessage GetUserReports(int uid)
        {
            using (OnlineExaminationEntities db = new OnlineExaminationEntities())
            {
                var report = db.Reports
                    .Where(y => (y.UserID == uid))
                     .Select(x => new
                     {
                         UserID = x.UserID,
                         UserName = x.LoginDetail.UserName,
                         ExamID = x.ExamID,
                         Mark1 = x.marksL1,
                         Mark2 = x.marksL2,
                         Mark3 = x.marksL3,
                         TechName = x.Technology.TechnologyName
                     })
                     .ToArray();

                return this.Request.CreateResponse(HttpStatusCode.OK, report);
            }
        }

        [HttpGet]
        [Route("userprofile")]
        public HttpResponseMessage GetProfiles(int uid)
        {
            using (OnlineExaminationEntities db = new OnlineExaminationEntities())
            {
                var profile = db.LoginDetails
                    .Where(y => (y.Type == "user" && y.UserID ==uid) )
                    .Select(x => new
                    {
                        UserID = x.UserID,
                        UserName = x.UserName,
                        Email = x.Email,
                        DOB = x.DOB,
                        Qualification = x.Qualification,
                        Phone = x.Mobile,
                        City = x.City,
                        YOC = x.Year_of_completion,
                        State = x.State
                    })
                    .ToArray();

                return this.Request.CreateResponse(HttpStatusCode.OK, profile);
            }
        }

        [HttpPut]
        [Route("submitscore")]
        
        public HttpResponseMessage SubmitScore(Report card)
        {
            using (OnlineExaminationEntities db = new OnlineExaminationEntities())
            {
                db.Reports.Add(card);
                db.SaveChanges();
                return this.Request.CreateResponse(HttpStatusCode.OK, "submitted");
            }
        }
    }



}
