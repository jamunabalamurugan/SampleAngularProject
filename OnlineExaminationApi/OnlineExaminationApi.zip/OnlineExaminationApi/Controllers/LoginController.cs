﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OnlineExaminationApi.Models;


namespace OnlineExaminationApi.Controllers
{
    public class LoginController : ApiController
    {
        OnlineExaminationEntities db = new OnlineExaminationEntities();


        [HttpPost]
        [Route("validatelogin")]

        public dynamic ValidateLogin(Login user)
        {
            using (OnlineExaminationEntities db = new OnlineExaminationEntities())
            {
                int? ID = db.loginvalidation(user.Email, user.Password, user.Type).FirstOrDefault();
                return this.Request.CreateResponse(HttpStatusCode.OK, ID);
            }
        }
    }
}
