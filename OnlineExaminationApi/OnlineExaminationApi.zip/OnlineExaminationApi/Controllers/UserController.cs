﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Net.Mail;

using OnlineExaminationApi.Models;
using System.Data.Entity;

namespace OnlineExaminationApi.Controllers
{
    public class UserController : ApiController
    {
        OnlineExaminationEntities db = new OnlineExaminationEntities();

        [HttpPost]
        [Route("register")]

        public HttpResponseMessage Register(LoginDetail user)
        {
            user.Type = "user";
            db.LoginDetails.Add(user);
            db.SaveChanges();
            return this.Request.CreateResponse(HttpStatusCode.OK, "added successfully");
        }

        [HttpGet]
        [Route("login")]
        public HttpResponseMessage GetLogin(Login login)
        {
            using(OnlineExaminationEntities db = new OnlineExaminationEntities())
            {
                var userdata = db.LoginDetails
                    .Where(y => (y.Email == login.Email && y.Password == login.Password))
                    .Select(x => new { x.UserID, x.UserName });

                if (userdata != null)
                {
                    return this.Request.CreateResponse(HttpStatusCode.OK, userdata);
                }
                else
                {
                    return this.Request.CreateResponse(HttpStatusCode.OK, -1);
                }
            }

        }

        [HttpGet]
        [Route("verifymail")]
        public HttpResponseMessage Verify(string email)
        {
            using (OnlineExaminationEntities db = new OnlineExaminationEntities())
            {
                int? res = db.LoginDetails
                        .Where(x => x.Email == email)
                        .Select(c => c.UserID).FirstOrDefault();
                if (res == 0)
                {
                    return this.Request.CreateResponse(HttpStatusCode.OK,-1);
                }
                else
                {
                    //MailMessage mail = new MailMessage();
                    //SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

                    //mail.From = new MailAddress("sujinhsgowda333@gmail.com");
                    //mail.To.Add("likith08154@gmail.com");
                    //mail.Subject = "Password Reset Link";
                    //mail.Body = "This is for testing SMTP mail from GMAIL";
                    //mail.From = new MailAddress("sujinhsgowda333@gmail.com");
                    //mail.To.Add("likith08154@gmail.com");
                    //mail.Subject = "Hello World";
                    //mail.Body = "<h1>Hello</h1>";
                    //mail.IsBodyHtml = true;
                    //using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                    //{
                    //    smtp.Credentials = new NetworkCredential("email@gmail.com", "password");
                    //    smtp.EnableSsl = true;
                    //    smtp.Send(mail);
                    //}
                    //SmtpServer.Port = 587;
                    //SmtpServer.Credentials = new System.Net.NetworkCredential("imnotubro@gmail.com"", "");
                    //SmtpServer.EnableSsl = true;

                    //SmtpServer.Send(mail);


                    return this.Request.CreateResponse(HttpStatusCode.OK, res);
                }
            }
        }


        [HttpPut]
        [Route("resetpassword")]
        public HttpResponseMessage ResetPassword(int id, string newpassword)
        {
            using (OnlineExaminationEntities db = new OnlineExaminationEntities())
            {
                LoginDetail newdetail = db.LoginDetails.Find(id);
                newdetail.Password = newpassword;
                db.Entry(newdetail).State = EntityState.Modified;
                db.SaveChanges();

                return this.Request.CreateResponse(HttpStatusCode.OK, 1);
                //int? res = db.LoginDetails
                //    .Where(x => (x.Email == email))
                //    .Select(y => (y.UserID)).FirstOrDefault();


            }
        }

    }
}
